use LWP::Simple;

print get('http://willezurmacht.herokuapp.com/');
